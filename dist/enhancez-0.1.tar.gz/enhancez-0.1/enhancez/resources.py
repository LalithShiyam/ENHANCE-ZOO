#!/usr/bin/env python3
            
# -*- coding: utf-8 -*-

'''
.. module:: resources
   :platform: Unix, Windows
   :synopsis: This module manages resources.

.. moduleauthor:: Lalith Kumar Shiyam Sundar  <lalith.shiyamsundar@meduniwien.ac.at>

'''

# Your code here
