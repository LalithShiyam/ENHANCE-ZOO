#!/usr/bin/env python3
            
# -*- coding: utf-8 -*-

'''
.. module:: input_validation
   :platform: Unix, Windows
   :synopsis: This module validates user input.

.. moduleauthor:: Lalith Kumar Shiyam Sundar  <lalith.shiyamsundar@meduniwien.ac.at>

'''

# Your code here
