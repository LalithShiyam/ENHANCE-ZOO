#!/usr/bin/env python3
            
# -*- coding: utf-8 -*-

'''
.. module:: __init__
   :platform: Unix, Windows
   :synopsis: Initialization module for the package.

.. moduleauthor:: Lalith Kumar Shiyam Sundar  <lalith.shiyamsundar@meduniwien.ac.at>

'''

# Your code here
