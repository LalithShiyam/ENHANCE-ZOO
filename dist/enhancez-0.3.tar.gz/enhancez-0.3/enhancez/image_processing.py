#!/usr/bin/env python3
            
# -*- coding: utf-8 -*-

'''
.. module:: image_processing
   :platform: Unix, Windows
   :synopsis: This module handles image processing tasks.

.. moduleauthor:: Lalith Kumar Shiyam Sundar  <lalith.shiyamsundar@meduniwien.ac.at>

'''

# Your code here
