#!/usr/bin/env python3
            
# -*- coding: utf-8 -*-

'''
.. module:: download
   :platform: Unix, Windows
   :synopsis: This module handles downloading of files.

.. moduleauthor:: Lalith Kumar Shiyam Sundar  <lalith.shiyamsundar@meduniwien.ac.at>

'''

# Your code here
