#!/usr/bin/env python3
            
# -*- coding: utf-8 -*-

'''
.. module:: display
   :platform: Unix, Windows
   :synopsis: This module is responsible for displaying information.

.. moduleauthor:: Lalith Kumar Shiyam Sundar  <lalith.shiyamsundar@meduniwien.ac.at>

'''

# Your code here
